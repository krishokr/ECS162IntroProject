# ECS162Project1
#The Amazing 6
# Team: Karan Gupta, Saifedin Maani, Shelby Sakamoto, Cathy Wang, Kris Hokr, Harman
